package com.Items;
//this is the trap class. Similar to an enemy but this class shoots arrows vertically across the map. When in contact, player is dead.
import java.awt.*;
import java.awt.geom.*;
import com.Character.Player.Player;
import com.Util.ImageLoader;
import processing.core.PVector;
import com.Util.SoundPlayer;

public class Traps {
    private Image arrowImage;

    public PVector pos;
    private float scale = 0.5f;            

    private boolean active = false;
    private float speed = 8f;
    private long nextFire = 0L;
    private long coolDown = 3000L;

    private final Area outline = new Area();
    private Rectangle2D.Float collisionBox;
    private final SoundPlayer swooshSfx = new SoundPlayer();

    public Traps() {
        arrowImage = ImageLoader.loadImage("assets/arrow1.png");
        this.pos = new PVector();
        
        float hw = 10f, hh = 28f; 
        collisionBox = new Rectangle2D.Float(-hw, -hh, hw * 2f, hh * 2f);
        outline.add(new Area(collisionBox));
    }

    public void update(int screenW, int screenH) {
        long now = System.currentTimeMillis();

        if (!active && now >= nextFire && arrowImage != null) {
            int iw = arrowImage.getWidth(null);
            int ih = arrowImage.getHeight(null);
            float minX = iw * 0.5f, maxX = Math.max(minX + 1, screenW - iw * 0.5f);
            pos.x = minX + (float)Math.random() * (maxX - minX);
            pos.y = -ih;
            active = true;
            swooshSfx.playOnce("swoosh.mp3");

        }
        if (!active) return;

        pos.y += speed;

        if (pos.y > screenH + (arrowImage != null ? arrowImage.getHeight(null) : 0)) {
            active = false;
            nextFire = now + coolDown;
            swooshSfx.stop();
        }
    }

    public void draw(Graphics2D g) {
        if (!active || arrowImage == null) return;

        AffineTransform old = g.getTransform();
        g.translate(pos.x, pos.y);
        g.scale(scale, scale);

        int iw = arrowImage.getWidth(null);
        int ih = arrowImage.getHeight(null);
        g.drawImage(arrowImage, -iw / 2, -ih / 2, null);

        g.setTransform(old);
    }

    public Shape getBoundary() {
        if (!active) return null;
        AffineTransform at = new AffineTransform();
        at.translate(pos.x, pos.y);
        at.scale(scale, scale);
        return at.createTransformedShape(outline);
    }

    public boolean detectCollision(Player p) {
        if (!active) return false;
        Shape a = getBoundary();
        Shape b = p.getBoundary();
        if (a == null || b == null) return false;

        if (!a.getBounds2D().intersects(b.getBounds2D())) return false;

        Area aa = new Area(a);
        aa.intersect(new Area(b));
        return !aa.isEmpty();
    }

    public boolean isActive() { return active; }
    public void setScale(float s) { this.scale = s; }
    
    public void stopAudio() { swooshSfx.stop(); }

}
