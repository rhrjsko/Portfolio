package com.Items;
//this is the Battery class. Used to charge the flashlight for a longer range. 
import java.awt.*;
import java.awt.geom.*;

import com.Character.Player.Player;

import processing.core.PVector;
import com.Util.SoundPlayer;

public class Battery {
    public PVector pos;
    private float radius = 16f;      
    private float value  = 0.35f;     // how much to add to the meter
    private Shape shape;

    public Battery(float x, float y) {
        pos = new PVector(x, y);
        shape = new Ellipse2D.Float(x - radius, y - radius, radius*2, radius*2);
    }

    public float getValue()    { return value; }
    public Shape getBoundary() { return shape; }

    public void draw(Graphics2D g) {
        g.setColor(new Color(255, 230, 80));
        g.fill(shape);
        g.setColor(new Color(180, 140, 30));
        g.draw(shape);	

        // tiny plus sign
        g.setColor(new Color(100, 60, 10));
        int cx = (int) pos.x, cy = (int) pos.y;
        g.drawLine(cx - 6, cy, cx + 6, cy);
        g.drawLine(cx, cy - 6, cx, cy + 6);
    }
    
    public boolean detectCollision(Player c) {
        Shape a = getBoundary();
        Shape b = c.getBoundary();

        if (!a.getBounds2D().intersects(b.getBounds2D())) return false;

        Area aa = new Area(a);
        aa.intersect(new Area(b));
        return !aa.isEmpty();
    }
}
