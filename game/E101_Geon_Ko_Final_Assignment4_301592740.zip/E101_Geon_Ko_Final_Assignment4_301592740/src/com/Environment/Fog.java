package com.Environment;
//this is the fog class. It uses Perlin noise to create fog like shapes that mimic the movement of an actual fog. I tried to cover most of the screen
//it was too laggy and rigged so I decided to go with this.
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.util.concurrent.ThreadLocalRandom;

import processing.core.PApplet; 

public class Fog {
    private float xPos, yPos;
    private int width, height;

    private int count = 24;     // number of puffs
    private float riseTick = 0.30f;  // baseline upward speed (pixels/tick)
    private float wiggle = 40f;  
    private float timeStep = 0.02f;  

    private final Ellipse2D.Float oval = new Ellipse2D.Float();
    private float t = 0f;         

    private int lastW = 0, lastH = 0;

    private final PApplet pa = new PApplet(); 
    
    // One puff of fog
    private static final class Puff {
        float x, y;          
        float size;          
        float speed;        
        float rise;          
        float seedX, seedY;   
        Color color;          
    }

    private final Puff[] puffs = new Puff[count];

    public Fog(float x, float y, int w, int h) {
        xPos = x; yPos = y; width = w; height = h;
        for (int i = 0; i < count; i++) puffs[i] = new Puff();
        reseedPuffs(Math.max(1, w), Math.max(1, h));
        lastW = w; lastH = h;
    }

    //update placement and optionally reseed puff positions if size changed. 
    public void setBounds(float x, float y, int w, int h) {
        xPos = x; yPos = y; width = w; height = h;
        if (w > 5 && h > 5 && (w != lastW || h != lastH)) {
            reseedPuffs(w, h);
            lastW = w; lastH = h;
        }
    }

    //fill puff properties with reasonable random values
    private void reseedPuffs(int w, int h) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Puff p : puffs) {
            p.x = r.nextFloat() * w;
            p.y = r.nextFloat() * h;

            p.size  = 18f + r.nextFloat() * 40f;      
            p.speed = 0.6f + r.nextFloat() * 0.8f;   
            p.rise  = riseTick * (0.8f + r.nextFloat() * 0.6f); 

            p.seedX = r.nextFloat() * 10f;
            p.seedY = r.nextFloat() * 10f;

            int alpha = 40 + r.nextInt(36);           // 40..75
            p.color = new Color(235, 235, 235, alpha);
        }
    }

    //draw the fog at its current placement using Perlin noise for drift
    public void drawFog(Graphics2D g2) {
        if (width <= 0 || height <= 0) return;

        t += timeStep; // advance global time used by noise

        AffineTransform saved = g2.getTransform();
        g2.translate(xPos, yPos);

        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Puff p : puffs) {
            //rise up
            p.y -= p.rise;
            if (p.y < -p.size) {
                p.y    = height + p.size;
                p.x    = r.nextFloat() * width;
                p.size = 18f + r.nextFloat() * 40f;
                p.speed = 0.6f + r.nextFloat() * 0.8f;
                p.rise  = riseTick * (0.8f + r.nextFloat() * 0.6f);
                p.seedX = r.nextFloat() * 10f;
                p.seedY = r.nextFloat() * 10f;
                int alpha = 40 + r.nextInt(36);
                p.color = new Color(235, 235, 235, alpha);
            }

            float nx = pa.noise(p.seedX + t * p.speed, p.seedY) * 2f - 1f;
            float px = p.x + nx * wiggle;

            float jy = (pa.noise(p.seedX, p.seedY + t * 0.3f) - 0.5f) * 6f;

            g2.setColor(p.color);
            oval.setFrame(px - p.size * 0.5f, (p.y + jy) - p.size * 0.28f, p.size, p.size * 0.56f);
            g2.fill(oval);
        }

        g2.setTransform(saved);
    }
}
