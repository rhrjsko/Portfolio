package com.Environment;
//this is the HauntedMansion class. Draws the background of a hallway in mansion. Suits the theme for its horror game genre.
import java.awt.*;

import java.awt.image.BufferedImage;
import com.Util.ImageLoader;

public class HauntedMansion {
    private BufferedImage bgImage;
    private final Color fallbackColor = new Color(48, 0, 96);

    public HauntedMansion() {
        bgImage = ImageLoader.loadImage("assets/hallway.png");
        if (bgImage == null) {
            System.err.println("failed to load assets/hallway.png");
        }
    }

    public void draw(Graphics2D g2d, int width, int height) {
        if (bgImage != null) {
        	g2d.drawImage(bgImage, 0, 0, width, height, null);
        } else {
            Color old = g2d.getColor();
            g2d.setColor(fallbackColor);
            g2d.fillRect(0, 0, width, height);
            g2d.setColor(old);
        }
    }
}
