package com.Environment;
//this is the portal class. When came across it, the player is teleported to the next level, when successfully pass the level 3 portal, the player has won.
import java.awt.*;
import java.awt.geom.*;
import com.Character.Player.Player;
import processing.core.PVector;

public class Portal {
    private final Ellipse2D.Double collider; 
    private final Area outline;
    private double scale = 1.0;

    public PVector pos = new PVector();
    private boolean active = true;

    public Portal(float x, float y, double radius) {
        this.pos.set(x, y);
        this.collider = new Ellipse2D.Double(-radius, -radius, radius * 2, radius * 2);
        this.outline  = new Area(collider);
    }

    public void setPos(float x, float y) {
    	this.pos.set(x, y); 
    }
    
    public boolean isActive() {
    	return active; 
    }
    
    public void setActive(boolean on) {
    	this.active = on;
    }

    public Shape getBoundary() {
        AffineTransform at = new AffineTransform();
        at.translate(pos.x, pos.y);
        at.scale(scale, scale);
        return at.createTransformedShape(outline);
    }

    public boolean detectCollision(Player p) {
        Area a = new Area(getBoundary());
        a.intersect(new Area(p.getBoundary()));
        return !a.isEmpty();
    }

    public void draw(Graphics2D g) {
        if (!active) return;
        AffineTransform old = g.getTransform();
        g.translate(pos.x, pos.y);
        g.setStroke(new BasicStroke(4f));
        g.setColor(new Color(120, 180, 255, 180));
        g.draw(collider);
        g.setColor(new Color(120, 180, 255, 60));
        g.fill(new Ellipse2D.Double(-collider.width/2.5, -collider.height/2.5,
                                    collider.width/1.25, collider.height/1.25));
        g.setTransform(old);
    }
}
