package com.Util;
//class to play sound
import ddf.minim.*;

public class SoundPlayer {
  private final Minim minim;
  private AudioPlayer player;

  public SoundPlayer() {
    minim = new Minim(new MinimHelper()); // ← your class
  }

  public void playOnce(String path) {
    stop();
    player = minim.loadFile(path);   
    if (player == null) {
        System.err.println("[SoundPlayer] Couldn't load: " + path);
        return; // ← don't throw on the UI thread
      }
      player.play();
  }

  public void loop(String path) {
    stop();
    player = minim.loadFile(path);
    if (player == null) {
        System.err.println("[SoundPlayer] Couldn't load: " + path);
        return;
      }    player.loop();
  }

  public void stop() {
    if (player != null) { player.close(); player = null; }
  }

  public void dispose() { stop(); minim.stop(); }
}
