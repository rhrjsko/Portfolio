package com.GameManager;
//this is the jumpscare class. When player is contacted by enemy or arrow, an image pops up with a screaming audio. Meant to be scary :).
import java.awt.*;
import java.awt.geom.AffineTransform;
import com.Util.ImageLoader;

public class Jumpscare {
    private Image jumpImage;
    private long startMs = 0L;
    private long durationMs = 1000L; 
    private boolean active = false;

    public Jumpscare() {
        jumpImage = ImageLoader.loadImage("assets/jumpscare.png");
        if (jumpImage == null) {
            System.err.println("Failed to load jumpscare image from assets/jumpscare.png");
        }
    }

    public void trigger() {
        if (active) return;
        startMs = System.currentTimeMillis();
        active = true;
    }

    public boolean isActive() {
        if (!active) return false;
        return (System.currentTimeMillis() - startMs) < durationMs;
    }

    public boolean isFinished() {
        return active && (System.currentTimeMillis() - startMs) >= durationMs;
    }

    public void reset() {
        active = false;
        startMs = 0L;
    }

    public void draw(Graphics2D g, int w, int h) {
        if (!isActive()) return;
        if (jumpImage == null) return;

        int iw = jumpImage.getWidth(null);
        int ih = jumpImage.getHeight(null);
        if (iw <= 0 || ih <= 0) return;

        int x = (w - iw) / 2;
        int y = (h - ih) / 2;

        g.drawImage(jumpImage, x, y, null);
    }

}
