package com.GameManager;
/*This is the Gamepanel class. This is where everything is drawn and set to action. I initialized everything. Has methods to respawn enemy, when start
 * intro, when to activate ending, and when to reset everything. */

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Area;
import java.util.ArrayList;

import com.Environment.HauntedMansion;
import com.Character.Player.Flashlight;
import com.Character.Player.Player;
import com.Character.Enemies.*;
import processing.core.PVector;
import com.Environment.Portal;
import com.Items.Battery;  
import com.Items.Traps;
import com.Util.SoundPlayer;
import com.Environment.Fog;  

public class GamePanel extends JPanel implements ActionListener {
    private final Intro intro;
    private final Ending ending;

    private final Player player;
    private final HauntedMansion mansion;
    private final Flashlight flashlight;
    private final Timer timer;    
    private final Jumpscare jumpscare;
    
    private final Announcer announcer = new Announcer(); //for comments

    private int level = 1; //portal initial level
    private Portal portal;
    private long levelOverlayUntil = 0L; 
    
    private boolean awaitingEnd = false;
    private long pauseTime = 0L;
    
    private boolean tipBatteryPending = false; //boolean for when the text should show
    private boolean tipArrowsPending  = false; //boolean for when the text should show
    
    private ArrayList<Battery> batteries = new ArrayList<>();     
    private final ArrayList<Enemies> enemies = new ArrayList<>();
    private final ArrayList<Traps> arrows = new ArrayList<>();

    private boolean gameOver = false;
    
    //fsm game states
    private static final int STATE_INTRO  = 0;
    private static final int STATE_HOWTO  = 1;
    private static final int STATE_PLAY   = 2;
    private static final int STATE_WIN    = 3;
    private static final int STATE_LOSE   = 4;
    
    private int state = STATE_INTRO; //current state

    private long jumpscareUntil = 0L;
    private final SoundPlayer screamSfx = new SoundPlayer();
    private final SoundPlayer portalSfx = new SoundPlayer();
    private final SoundPlayer winSfx = new SoundPlayer();
    private final SoundPlayer batterySfx = new SoundPlayer();

   
    private float batteryLevel = 1f;               
    private static final float BATTERY_PICKUP_AMOUNT = 0.35f;//amount it charges the battery
    private static final float BATTERY_DRAIN_ON   = 0.0025f; // faster when light ON
    
    private final Fog fog = new Fog(0, 0, 1, 1); // size set each frame


    public GamePanel() {
        setPreferredSize(new Dimension(1500, 700));
        setBackground(Color.BLACK);

        intro = new Intro();
        ending = new Ending(this);
        jumpscare = new Jumpscare();
        player = new Player(50, 400);
        
        mansion = new HauntedMansion();
        flashlight = new Flashlight(0, 0, Color.YELLOW);
        batteries.add(new Battery(350, 350)); 
        
        respawnEnemiesForLevel(level);

        setFocusable(true);
        addKeyListener(intro);
        addMouseListener(intro);
        addKeyListener(player);
        addKeyListener(ending);
        addMouseListener(ending);
        
        addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (state == STATE_PLAY) {
                    if (e.getKeyCode() == KeyEvent.VK_SPACE && batteryLevel > 0f) {
                        flashlight.toggle();
                    }
                    player.keyPressed(e);
                }
            }
            @Override public void keyReleased(KeyEvent e) {
                if (state == STATE_PLAY) {
                    player.keyReleased(e);
                }
            }
        });
        
        addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                Point p = e.getPoint();
                switch (state) {
                    case STATE_INTRO:
                        if (buttonStart().contains(p)) state = STATE_HOWTO;
                        break;
                    case STATE_HOWTO:
                        if (buttonPlay().contains(p))  {
                            state = STATE_PLAY;
                            String first = (level == 3)
                                    ? "Reach the portal to WIN the game"
                                    : "Reach the portal to move on to next level";
                            announcer.say(first, 3000);

                            // what to show next, after the first message disappears
                            tipBatteryPending = true;        // show collect battery
                            tipArrowsPending  = (level == 3); // on level 3, also warn about arrows
                        }                        break;
                    case STATE_WIN:
                    case STATE_LOSE:
                        if (buttonRestart().contains(p)) {
                            restartGame();
                            state = STATE_INTRO;
                        }
                        break;
                }
                repaint();
            }
        });

        timer = new Timer(20, this);
        timer.start();
    }
    
    //spawn ghost
    private void spawnGhosts(int count, float speed) {
        int minX = 200;
        int rangeX = Math.max(400, getWidth() - minX - 150);
        int h = Math.max(400, getHeight());

        for (int i = 0; i < count; i++) {
            int x = minX + (int)(Math.random() * rangeX);
            int y = 100  + (int)(Math.random() * Math.max(200, h - 200));
            enemies.add(new Ghost(x, y, speed, new Color(255,255,255,150)));
        }
    }

    //spawn zombies
    private void spawnZombies(int count, float speed, boolean verticalDrift) {
        int minX = 200;
        int rangeX = Math.max(400, getWidth() - minX - 150);
        int h = Math.max(400, getHeight());

        for (int i = 0; i < count; i++) {
            int x = minX + (int)(Math.random() * rangeX);
            int y = 100  + (int)(Math.random() * Math.max(200, h - 200));
            Zombie z = new Zombie(x, y, speed, new Color(80,120,80));
            if (verticalDrift) z.vel = new PVector(0, z.speedMag);
            enemies.add(z);
        }
    }

    //clear everything and respawn instances that belong to in certain level
    private void respawnEnemiesForLevel(int lvl) {
        enemies.clear();
        if (lvl < 1) lvl = 1;
        arrows.clear();

        switch (lvl) {
            case 1:
                spawnGhosts(6, 2.0f);
                break;

            case 2:
                spawnGhosts(8, 2.2f);
                spawnZombies(5, 1.6f, true); // drifting vertical walkers
                break;

            case 3:
                spawnGhosts(10, 2.5f);
                spawnZombies(7, 1.8f, false);
                enemies.add(new Ghost(300, 300, 3.2f, new Color(255,255,255,220))); // “elite”
                for (int i = 0; i < 3; i++) {
                    arrows.add(new Traps());   
                }
                break;
                
        }
    }
    
    private boolean handleEnemy(Enemies en, Area beamArea) {
        en.update(beamArea, player);

        if (en.pos.x < 0 || en.pos.x > getWidth())  en.vel.x *= -1;
        if (en.pos.y < 0 || en.pos.y > getHeight()) en.vel.y *= -1;

        if (!en.isStunned() && en.detectCollision(player)) {
            player.setAlive(false);
            silenceAllAudio();
            screamSfx.playOnce("scream.mp3");
            long now = System.currentTimeMillis();
            jumpscare.trigger();
            jumpscareUntil = now + 1000L;
            state = STATE_LOSE;
            return true;
        }
        return false;
    }
    
    //silence audio
    private void silenceAllAudio() {
        player.stopAllAudio();
        batterySfx.stop();
        screamSfx.stop();
        portalSfx.stop();
        winSfx.stop();          
        for (Traps t : arrows) t.stopAudio();

    }
    
    
    private Rectangle buttonStart()   { 
    	return new Rectangle(getWidth()/2 - 90, getHeight()/2 + 40, 180, 40); 
    }
    private Rectangle buttonPlay()    { 
    	return new Rectangle(getWidth()/2 - 90, getHeight()/2 + 120, 180, 40); 
    }
    private Rectangle buttonRestart() {
    	return new Rectangle(getWidth()/2 - 90, getHeight()/2 + 120, 180, 40); 
    }
    
    private void drawWeb(Graphics2D g2,int cx, int cy, double radius, int rings, int initialRings) {
        // base case
        if (rings <= 0) return;

        // divide circle by 16, for each angle we use xs, ys and set offset by using cx and cy.
        double step = 2 * Math.PI / 16;
        int[] xs = new int[16];
        int[] ys = new int[16];
        for (int i = 0; i < 16; i++) {
            double ang = i * step;	
            xs[i] = cx + (int)(Math.cos(ang) * radius);
            ys[i] = cy + (int)(Math.sin(ang) * radius);
        }
        
        // draw the rings
        g2.drawPolygon(xs, ys, 16);

        // since at first rings equal the amount of initial ring, we pass and draw lines stretching out on outer most ring.
        if (rings == initialRings) {
            for (int i = 0; i < 16; i++) {
                g2.drawLine(cx, cy, xs[i], ys[i]);
            }
        }

        // recursive step for the next ring
        drawWeb(g2,
                cx, cy,
                radius * 0.7,   // to shrink the rings
                rings - 1,	//draw less and less rings
                initialRings);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (state) {
        case STATE_INTRO:
        case STATE_HOWTO:
        case STATE_WIN:
            repaint(); 
            return;

        case STATE_LOSE:
            repaint();
            return;

        case STATE_PLAY:
            if (tipBatteryPending && !announcer.isShowing()) {
                announcer.say("Collect batteries for longer flashlight range", 3000);
                tipBatteryPending = false;
            } else if (tipArrowsPending && !announcer.isShowing()) {
                announcer.say("Dodge the arrows!", 2500);
                tipArrowsPending = false;
            }
            break; 
    }
        
        player.update();
        flashlight.setPos(player.getPos());

        Shape beam = flashlight.getBeamBoundary();
        Area beamArea;
        boolean beamOn;

        if (beam == null) {
            beamArea = null;
            beamOn = false;
        } else {
            beamArea = new Area(beam); 
            beamOn = true;
        }

        if (beamOn) {
            batteryLevel -= BATTERY_DRAIN_ON;  
        } 
        
        if (batteryLevel < 0f) {
            batteryLevel = 0f;
        }

        flashlight.setRangeScale(1f + 0.8f * batteryLevel);
        
        if (portal == null && getWidth() > 0 && getHeight() > 0) {
            portal = new Portal(getWidth() - 120, getHeight() / 2f, 40);
        } else if (portal != null && portal.isActive()) {
            portal.setPos(getWidth() - 120, getHeight() / 2f);
        }
        
        for (int i = 0; i < batteries.size(); i++) {
            Battery b = batteries.get(i);
            if (b.detectCollision(player)) {
                batteryLevel = Math.min(1f, batteryLevel + BATTERY_PICKUP_AMOUNT);
                batteries.remove(i);

                batterySfx.playOnce("batteryCharge.mp3");  // ← add this (file at assets/batteryCharge.mp3)

                break;
            }
        }
           

        for (Enemies en : enemies) {
            if (handleEnemy(en, beamArea)) {
                repaint();
                return; 
            }
        }
        
        for (Traps t : arrows) {
            t.update(getWidth(), getHeight());
            if (t.isActive() && t.detectCollision(player)) {
                player.setAlive(false);
                silenceAllAudio();  
                screamSfx.playOnce("scream.mp3");
                long now = System.currentTimeMillis();
                jumpscare.trigger();
                jumpscareUntil = now + 1000L;
                state = STATE_LOSE;
                repaint();
                return;
            }

        }

        enemies.removeIf(Enemies::isDead);
        if (!gameOver && portal != null && portal.isActive()
                && System.currentTimeMillis() >= levelOverlayUntil
                && portal.detectCollision(player)) {
            portalSfx.playOnce("teleport.mp3");   

            goToNextLevel();
        }
        repaint();
    }
    
    private void goToNextLevel() {
        level++;
        levelOverlayUntil = System.currentTimeMillis() + 900; // show banner ~0.9s
        
        if (level > 3) {
            state = STATE_WIN;
            silenceAllAudio();             // ensure no loops underneath
            winSfx.playOnce("applause.mp3"); //cheer when game is won
            return;
        }
        
        batteries.clear();
        batteries.add(new Battery(320, 320));

        player.setPos(new PVector(50, 400));
        player.setAlive(true);

        respawnEnemiesForLevel(level);
        
        announcer.say(
                level == 3 ? "Reach the portal to WIN the game"
                           : "Reach the portal to move on to next level",3000);
        tipBatteryPending = true;         
        tipArrowsPending  = (level == 3); 
        

        if (portal != null) portal.setActive(true);
        
    }

    void restartGame() {
        gameOver = false;
        silenceAllAudio(); 
        intro.reset();
        ending.reset();
        
        awaitingEnd = false;
        pauseTime = 0L;
        
        level = 1;     
        levelOverlayUntil = 0L;    

        player.setAlive(true);
        player.setPos(new PVector(50, 400));

        respawnEnemiesForLevel(level);
        jumpscare.reset();
        
        batteryLevel = 0.25f;     
        batteries.clear();
        batteries.add(new Battery(350, 350));
        
        if (portal == null && getWidth() > 0 && getHeight() > 0) {
            portal = new Portal(getWidth() - 120, getHeight() / 2f, 40);
        }
        if (portal != null) {
            portal.setActive(true);
            portal.setPos(getWidth() - 120, getHeight() / 2f);
        }
    }

    public boolean isGameOver() {
        return state == STATE_LOSE;
    }
    
    private static Color batteryColor(float lvl) {
        if (lvl < 0.2f) return new Color(220,60,60);
        if (lvl < 0.5f) return new Color(240,200,70);
        return new Color(90,220,110);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D)g;
        switch (state) {
        case STATE_INTRO:
            intro.drawIntro(g2, getWidth(), getHeight());
            return;
        case STATE_HOWTO:
            intro.drawHowTo(g2, getWidth(), getHeight());
            return;
        case STATE_WIN:
            ending.drawWin(g2, getWidth(), getHeight());
            return;
        case STATE_LOSE:
            if (System.currentTimeMillis() <= jumpscareUntil) {
                jumpscare.draw(g2, getWidth(), getHeight());
            } else {
                ending.drawLose(g2, getWidth(), getHeight());
            }
            return;
        case STATE_PLAY:
            // draw world
            mansion.draw(g2, getWidth(), getHeight());
            for (Battery b : batteries) b.draw(g2);
            announcer.draw(g2, getWidth(), getHeight());
            
            fog.setBounds(0, 0, getWidth(), getHeight());
            fog.drawFog(g2);

            g2.setColor(new Color(200, 200, 200, 80));
            int cx = 1200, cy = 160, totalRings = 8;
            drawWeb(g2, cx, cy, Math.min(cx, cy) * 0.7, totalRings, totalRings);

            if (portal != null && portal.isActive()) portal.draw(g2);

            for (Enemies en : enemies) en.draw(g2);
            for (Traps t : arrows) t.draw(g2);

            flashlight.draw(g2);
            player.draw(g2);

            // level label
            g2.setColor(new Color(255, 255, 255, 220));
            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 18f));
            g2.drawString("LEVEL " + level, 20, 30);

            // battery HUD
            int x = 20, y = 44, w = 58, h = 26;
            g2.setColor(new Color(30,30,35,200));
            g2.fillRoundRect(x, y, w, h, 6, 6);
            g2.setColor(new Color(80,80,90));
            g2.drawRoundRect(x, y, w, h, 6, 6);
            g2.fillRect(x + w, y + h/4, 5, h/2); // tip of battery

            float lvl = Math.max(0f, Math.min(1f, batteryLevel));
            int pad = 3;
            g2.setColor(batteryColor(lvl));
            g2.fillRect(x + pad, y + pad, Math.round((w - pad*2) * lvl), h - pad*2);

            // level clear overlay 
            if (System.currentTimeMillis() < levelOverlayUntil) {
                g2.setFont(g2.getFont().deriveFont(Font.BOLD, 36f));
                g2.setColor(new Color(80, 200, 120, 230));
                g2.drawString("LEVEL CLEAR!", getWidth() / 2 - 140, 60);
            }
            return;
        }
    }
}
