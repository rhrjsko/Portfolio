package com.GameManager;
//this is the ending class. When the user is dead, it shows a black background with text saying game over. When pressed on the button 
//it guides you to intro page
import java.awt.*;

import java.awt.event.*;
import com.Util.ImageLoader;   

public class Ending implements KeyListener, MouseListener {
    private final GamePanel parent;
    private boolean started = false;
    private Image endingImage;

    public Ending(GamePanel parent) {
        this.parent = parent;
        
        endingImage = ImageLoader.loadImage("assets/endingcover.png");
        if (endingImage == null) {
            System.err.println("Could not load assets/endingcover.png");
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (parent.isGameOver()) {
            started = true;
        }
    }
    
    public Rectangle getRestartRect(int w, int h) { return new Rectangle(w/2 - 90, h/2 + 120, 180, 40); }

    public void drawWin(Graphics2D g, int w, int h) {
        g.setColor(Color.BLACK); g.fillRect(0,0,w,h);
        g.setColor(new Color(120,220,140));
        drawCenteredText(g, "CONGRATULATIONS!", w, 240, 44);
        g.setColor(Color.WHITE);
        drawCenteredText(g, "You escaped the mansion.", w, 290, 24);
        drawButton(g, getRestartRect(w,h), "Restart");
    }

    public void drawLose(Graphics2D g, int w, int h) {
        // background image
        if (endingImage != null) {
            g.drawImage(endingImage, 0, 0, w, h, null);   // full-bleed cover
        } else {
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, w, h);
        }

        g.setColor(new Color(240,80,80));
        drawCenteredText(g, "You were caught!", w, 260, 36);
        g.setColor(Color.WHITE);
        drawCenteredText(g, "Try again?", w, 300, 24);
        drawButton(g, getRestartRect(w,h), "Restart");
    }
    
    private void drawCenteredText(Graphics2D g, String s, int canvasW, int y, int size) {
        g.setFont(g.getFont().deriveFont(Font.BOLD, (float)size));
        FontMetrics fm = g.getFontMetrics();
        int x = (canvasW - fm.stringWidth(s)) / 2;
        g.drawString(s, x, y);
    }
    
    private void drawButton(Graphics2D g, Rectangle r, String label) {
        g.setColor(new Color(40,40,50,200));
        g.fillRoundRect(r.x, r.y, r.width, r.height, 12, 12);
        g.setColor(new Color(200,200,220));
        g.drawRoundRect(r.x, r.y, r.width, r.height, 12, 12);
        FontMetrics fm = g.getFontMetrics();
        int tx = r.x + (r.width - fm.stringWidth(label))/2;
        int ty = r.y + (r.height + fm.getAscent())/2 - 3;
        g.drawString(label, tx, ty);
    }
    
    @Override public void keyReleased(KeyEvent e)  {}
    @Override public void keyTyped   (KeyEvent e)  {}

    @Override
    public void mousePressed(MouseEvent e) {
        if (parent.isGameOver()) {
            started = true;
        }
    }
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseClicked (MouseEvent e) {}
    @Override public void mouseEntered (MouseEvent e) {}
    @Override public void mouseExited  (MouseEvent e) {}

    public boolean isStarted() {
        return started;
    }

    public void reset() {
        started = false;
    }

    public void draw(Graphics2D g2, int w, int h) {
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, w, h);

        g2.setColor(Color.RED);
        g2.setFont(new Font("SansSerif", Font.BOLD, 36));
        String msg = "GAME OVER";
        FontMetrics fm = g2.getFontMetrics();
        int x = (w - fm.stringWidth(msg))/2;
        int y = h/2 - fm.getHeight();
        g2.drawString(msg, x, y);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("SansSerif", Font.PLAIN, 18));
        String prompt = "Press any key or click to restart";
        fm = g2.getFontMetrics();
        x = (w - fm.stringWidth(prompt))/2;
        y += fm.getHeight()*2;
        g2.drawString(prompt, x, y);
    }
}
