package com.GameManager;
//Gameapp class extends off of Jframe and creates a main window for Jpanel to show.
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class GameApp extends JFrame {

	public GameApp(String title) {
		super(title);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(1300, 800);

		
		GamePanel panel = new GamePanel();
		
		this.add(panel);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		 SwingUtilities.invokeLater(() -> {
	            new GameApp("BooHoo");
	        });
	}
	
}
