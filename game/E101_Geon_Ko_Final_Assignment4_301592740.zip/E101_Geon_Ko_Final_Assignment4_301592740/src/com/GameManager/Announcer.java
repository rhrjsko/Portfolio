package com.GameManager;
//this is the Announcer class. This class is used to pop up instructions during the game
import java.awt.*;

public class Announcer {
    private String msg = null;
    private long until = 0L;
    private int y = 80;

    public void say(String text, long ms) {
        msg = text;
        until = System.currentTimeMillis() + ms;
    }

    public void clear() {
        msg = null; 
        until = 0L;
    }

    public boolean isShowing() {
        return msg != null && System.currentTimeMillis() < until;
    }

    public void draw(Graphics2D g, int w, int h) {
        if (msg == null) return;
        long now = System.currentTimeMillis();
        if (now >= until) { msg = null; return; }

        g.setFont(g.getFont().deriveFont(Font.BOLD, 20f));
        FontMetrics fm = g.getFontMetrics();
        int tw = fm.stringWidth(msg);
        int x  = (w - tw) / 2;
        int ty = y;

        g.setColor(new Color(0, 0, 0, 160));
        g.fillRoundRect(x - 12, ty - 24, tw + 24, 36, 10, 10);
        g.setColor(Color.WHITE);
        g.drawString(msg, x, ty);
    }
}
