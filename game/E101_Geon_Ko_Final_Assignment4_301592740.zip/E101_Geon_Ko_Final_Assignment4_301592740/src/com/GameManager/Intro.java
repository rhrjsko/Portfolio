package com.GameManager;
/*This is the intro class. Before the game starts, a black screen saying press anywhere to start appears. Click the button to transition into the game*/
import java.awt.*;

import java.awt.event.*;
import com.Util.ImageLoader;  

public class Intro implements KeyListener, MouseListener {
    private boolean started = false;
    private Image bgImage;  
    
    public Rectangle getStartRect(int w, int h) { return new Rectangle(w/2 - 90, h/2 + 40, 180, 40); }
    public Rectangle getPlayRect (int w, int h) { return new Rectangle(w/2 - 90, h/2 + 120, 180, 40); }

    public Intro() {
        bgImage = ImageLoader.loadImage("assets/introcover.png");
        if (bgImage == null) {
            System.err.println("Could not load assets/intro.png");
        }
    }

    public boolean isStarted() {
        return started;
    }

    public void reset() {
        started = false;
    }
    
    public void drawIntro(Graphics2D g, int w, int h) {
        if (bgImage != null) {
            g.drawImage(bgImage, 0, 0, w, h, null);
        } else {
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, w, h);
        }

        Rectangle r = getStartRect(w, h);
        drawButton(g, r, "Start");
    }
    
    public void drawHowTo(Graphics2D g, int w, int h) {
        g.setColor(Color.BLACK); g.fillRect(0,0,w,h);
        g.setColor(Color.WHITE);
        drawCenteredText(g, "How to Play", w, 200, 36);
        drawCenteredText(g, "• Move: WASD / Arrow Keys", w, 260, 20);
        drawCenteredText(g, "• Space: Toggle flashlight", w, 290, 20);
        drawCenteredText(g, "• Collect batteries for longer beam", w, 320, 20);
        drawCenteredText(g, "• Reach the portal to clear the level", w, 350, 20);
        drawCenteredText(g, "• Avoid ghosts, zombies (Lv2+), arrows (Lv3)", w, 380, 20);
        drawButton(g, getPlayRect(w,h), "Play");
    }
    
    private void drawButton(Graphics2D g, Rectangle r, String label) {
        g.setColor(new Color(40,40,50,200));
        g.fillRoundRect(r.x, r.y, r.width, r.height, 12, 12);
        g.setColor(new Color(200,200,220));
        g.drawRoundRect(r.x, r.y, r.width, r.height, 12, 12);
        FontMetrics fm = g.getFontMetrics();
        int tx = r.x + (r.width - fm.stringWidth(label))/2;
        int ty = r.y + (r.height + fm.getAscent())/2 - 3;
        g.drawString(label, tx, ty);
    }
    
    private void drawCenteredText(Graphics2D g, String s, int canvasW, int y, int size) {
        g.setFont(g.getFont().deriveFont(Font.BOLD, (float)size));
        FontMetrics fm = g.getFontMetrics();
        int x = (canvasW - fm.stringWidth(s)) / 2;
        g.drawString(s, x, y);
    }

    @Override public void keyPressed(KeyEvent e)   { started = true; }
    @Override public void keyReleased(KeyEvent e)  {}
    @Override public void keyTyped(KeyEvent e)     {}

    @Override public void mousePressed(MouseEvent e) { started = true; }
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseClicked(MouseEvent e)  {}
    @Override public void mouseEntered(MouseEvent e)  {}
    @Override public void mouseExited(MouseEvent e)   {}

    public void draw(Graphics2D g2, int w, int h) {
    	
        if (bgImage != null) {
            g2.drawImage(bgImage, 0, 0, w, h, null);
        } else {
            g2.setColor(Color.BLACK);
            g2.fillRect(0, 0, w, h);
        }

        g2.setFont(new Font("SansSerif", Font.BOLD, 48));
        String title = "Boo-Hoo?";
        FontMetrics fm = g2.getFontMetrics();
        int x = (w - fm.stringWidth(title))/2;
        int y = h/3;
        g2.setColor(Color.WHITE);
        g2.drawString(title, x, y);

        g2.setFont(new Font("SansSerif", Font.PLAIN, 24));
        String prompt = "Press any key or click to begin. Use WASD or Arrow keys to move. Space bar for flashlight!";
        fm = g2.getFontMetrics();
        x = (w - fm.stringWidth(prompt))/2;
        y += fm.getHeight()*2;
        g2.drawString(prompt, x, y);
    }
}
