package com.Character.Enemies;
/*this is the ghost class. A subclass of Enemies class. This class does everything that Enemies class can do, it overrides draw because it needs to have 
 * the image of a ghost.*/
import java.awt.*;
import java.awt.geom.*;
import java.awt.geom.Rectangle2D.Double;
import java.util.Random;

import com.Util.ImageLoader;

import processing.core.PVector;
import processing.core.PApplet;

public class Ghost extends Enemies {
    private Image ghostImage;
    private float imageScale = 0.25f;     

    public Ghost(int x, int y, float speedMag, Color c) {
        super(x, y, speedMag, c);

        ghostImage = ImageLoader.loadImage("assets/ghost1.png");
        if (ghostImage == null) {
            System.err.println("Failed to load ghost image from assets/ghost.png");
        }        
     

        setShapeAttributes();
        setOutline();
    }

    @Override
    public void draw(Graphics2D g) {
        AffineTransform at = g.getTransform();
        g.translate(pos.x, pos.y);
        g.scale(scale, scale);

        if (ghostImage != null) {
            int w = (int)(ghostImage.getWidth(null) * imageScale);
            int h = (int)(ghostImage.getHeight(null) * imageScale);
            g.drawImage(ghostImage, -w / 2, -h / 2, w, h, null);
        } else {
            g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 150));
            g.fillOval(-15, -20, 30, 40);
        }

        g.setTransform(at);
    }

}
