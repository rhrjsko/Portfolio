package com.Character.Enemies;
/*this is the Enemies class. It is an abstract parent class that zombies and ghosts extends off of.
this class is used to organize and gather common or shared methods and fields into one class. Made not to created as an instance
therefore, it is an abstract class.*/
import java.awt.*;

import java.awt.geom.*;

import com.Character.Player.Player;

import processing.core.PVector;

public abstract class Enemies {
    public PVector pos, vel;
    public int size;
    public Color color;
    public double scale;
    public float speedMag;
    public boolean alive = true;
        
    //fsm state for actions
    protected int state;
    protected final int ROAM    = 0;
    protected final int CHASE   = 1;
    protected final int STUNNED = 2;
    protected final int DEAD    = 3;
    
    private long stunUntil = 0L; //mark when stun ends
    protected static final long STUN_MS = 3000L; //stun duration
    
    protected float  CHASE_RADIUS     = 220f;
    protected double ROAM_TURN_CHANCE = 0.02;   
    protected float  ROAM_SPEED_MULT  = 0.6f;   
    
    
    public Area outline = new Area();
    protected Image sprite = null;         
    protected float imageScale = 1.0f;      
    protected Shape collisionShape = null;  
 
    public Enemies(int x, int y, float speedMag, Color c) {
        this.pos      = new PVector(x, y);
        this.speedMag = speedMag;
        this.color    = c;
        this.scale    = 1.0;
        this.vel    = PVector.fromAngle((float)(Math.random()*2*Math.PI)).mult(speedMag);

        setShapeAttributes();
        setOutline();
    }

    protected void setShapeAttributes() {
        collisionShape = new Rectangle2D.Double(-15, -20, 30, 30);
    }
    
    protected void setOutline() {
        outline = new Area();
        if (collisionShape != null) {
            outline.add(new Area(collisionShape));
        }
    }

    public abstract void draw(Graphics2D g);

    public void move() {
        pos.add(vel);
    }    
    public void stun(long millis) {
        state = STUNNED;
        stunUntil = System.currentTimeMillis() + millis;
        vel.mult(0); // freeze while being stun
    }
    
    public boolean isStunned() {
        return state == STUNNED; 
    }
    
    public boolean isDead() {
        return state == DEAD || !alive;
    }

    public Shape getBoundary() {
        AffineTransform at = new AffineTransform();
        at.translate(pos.x, pos.y);
        at.scale(scale, scale);
        return at.createTransformedShape(outline);
    }
    
    public boolean detectCollision(Player c) {
        Shape a = getBoundary();
        Shape b = c.getBoundary();

        if (!a.getBounds2D().intersects(b.getBounds2D())) return false;

        Area aa = new Area(a);
        aa.intersect(new Area(b));
        return !aa.isEmpty();
    }
  

    public void resolveCollision(Enemies other) {
        float angle = (float)Math.atan2(pos.y - other.pos.y, pos.x - other.pos.x);
        if (scale < other.scale) {
            vel = PVector.fromAngle(angle + (float)Math.PI).mult(speedMag);
        } else {
            other.vel = PVector.fromAngle(angle).mult(speedMag);
        }
    }
    
    public PVector getPos() {
        return pos; //return location
    }
    
    public void setScale(double s) {
        this.scale = s;
    }
    
    //follow player to kill them
    public void steerToward(PVector targetPos) {
        PVector toTarget = PVector.sub(targetPos, pos);
        float dist = toTarget.mag();
        if (dist < 1e-3f) return;

        toTarget.normalize().mult(speedMag);

        if (dist < 200) {
            vel.set(toTarget);
        } else {
            PVector blended = PVector.lerp(vel, toTarget, 2f);
            blended.normalize().mult(speedMag);
            vel.set(blended);
        }
    }
    
    
    public void update(Area beamArea, Player player) {
        if (isDead()) return;

        if (beamArea != null && state != DEAD) {
            Area me = new Area(getBoundary());
            me.intersect(beamArea);
            if (!me.isEmpty()) {
                stun(STUN_MS);
            }
        }

        if (state == STUNNED) {
            if (System.currentTimeMillis() >= stunUntil) {
                state = DEAD;
                alive = false; 
            }
            return; 
        }

        boolean canChase = (player != null && player.isAlive());
        if (canChase) {
            float dist = PVector.dist(pos, player.getPos());
            state = (dist <= CHASE_RADIUS) ? CHASE : ROAM;
        } else {
            state = ROAM;
        }

        if (state == CHASE) {
            steerToward(player.getPos());
            move();
        } else if (state == ROAM) {
            maybeWander();
            move();
        }
    }
    
    //roam around
    protected void maybeWander() {
        if (Math.random() < ROAM_TURN_CHANCE) {
            float angle = (float)(Math.random() * Math.PI * 2);
            vel = PVector.fromAngle(angle).mult(speedMag * ROAM_SPEED_MULT);
        } else {
            if (vel.mag() > 1e-3f) {
                vel.normalize().mult(speedMag * ROAM_SPEED_MULT);
            } else {
                float angle = (float)(Math.random() * Math.PI * 2);
                vel = PVector.fromAngle(angle).mult(speedMag * ROAM_SPEED_MULT);
            }
        }
    }
    
    
    

    
}