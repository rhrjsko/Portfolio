package com.Character.Enemies;
/*this is the Zombie class. Same as the Ghost class, this class also extends off from Enemies class. It does what Enemies class can do 
 * and draw method is also overriden to have zomebie image.*/
import java.awt.*;
import java.awt.geom.*;
import java.awt.geom.Rectangle2D.Double;

import com.Util.ImageLoader;

public class Zombie extends Enemies {
    private Image zombieImage;
    private float imageScale = 0.3f;
    private int walkTimer = 0;
    private final int maxWalkTime = 100;

    public Zombie(int x, int y, float speedMag, Color c) {
        super(x, y, speedMag, c);

        zombieImage = ImageLoader.loadImage("assets/zombie1.png");
        if (zombieImage == null) {
            System.err.println("Failed to load zombie image from assets/zombie.png");
        }

        setShapeAttributes();
        setOutline();
    }


    
    @Override
    public void draw(Graphics2D g) {
        AffineTransform at = g.getTransform();
        g.translate(pos.x, pos.y);
        g.scale(scale, scale);

        if (zombieImage != null) {
            int w = (int)(zombieImage.getWidth(null) * imageScale);
            int h = (int)(zombieImage.getHeight(null) * imageScale);
            g.drawImage(zombieImage, -w / 2, -h / 2, w, h, null);
        } else {
            g.setColor(color);
            g.fillRect(-15, -25, 30, 50);
            g.setColor(Color.DARK_GRAY);
            g.drawRect(-15, -25, 30, 50);
        }

        g.setTransform(at);
    }

}
