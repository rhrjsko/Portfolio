package com.Character.Player;
/*this is the player class. The main character which user plays around with. Using wasd or arrow keys, the user is able to move the player. When hit
  by an enemy the player dies. The player can use flashlight to kill enemies, get across the hallway safely to reach the portal to move on to the next level
  */
import processing.core.PVector;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;

import com.Util.ImageLoader;
import com.Util.SoundPlayer;   // ← add this import

public class Player implements KeyListener {
    private PVector pos, vel;

    private int size = 30;
    private double scale = 3.5;
    private float speedMag = 3f;
    private boolean alive = true;

    private boolean up, down, left, right;

    private BufferedImage bgImage;
    private Flashlight flashlight;
    
    private Rectangle2D.Double collisionBox;
    public Area outline = new Area();
    
    private boolean wasMoving = false; //boolean to check movement
    
    private final SoundPlayer walkSfx = new SoundPlayer();


    public Player(float x, float y) {
        pos = new PVector(x, y);
        vel = new PVector(0, 0);

        bgImage = ImageLoader.loadImage("assets/player.png");
        if (bgImage == null) {
            System.err.println("Failed to load assets/player.png");
        }
        
        setShapeAttributes();
        setOutline();
    }

    protected void setShapeAttributes() {
        collisionBox = new Rectangle2D.Double(-10, -25, 20, 30);
    }

    public void setOutline() {
        outline = new Area(collisionBox);
    }

    public void setFlashlight(Flashlight f) {
        this.flashlight = f;
    }

    //for movement
    public void update() {
        vel.set(0, 0);
        if (left)  vel.x = -speedMag;
        if (right) vel.x =  speedMag;
        if (up)    vel.y = -speedMag;
        if (down)  vel.y =  speedMag;
        pos.add(vel);
        
        boolean isMoving = alive && (vel.magSq() > 0.0001f);
        if (isMoving && !wasMoving) {
            // will look for assets/sfx/walking.mp3 via MinimHelper
            walkSfx.loop("walking.mp3");
        } else if (!isMoving && wasMoving) {
            walkSfx.stop();
        }
        wasMoving = isMoving;
        
    }

    public void draw(Graphics2D g) {
        AffineTransform old = g.getTransform();

        g.translate(pos.x, pos.y);
        g.rotate(vel.heading());
        g.scale(scale, scale);

        if (bgImage != null) {
            int w = size;
            int h = (int)(bgImage.getHeight() * (w / (double)bgImage.getWidth()));
            g.drawImage(bgImage, -w/2, -h/2, w, h, null);
        } else {
            g.setColor(Color.GREEN);
            g.fill(new Rectangle2D.Double(-size/2, -size/2, size, size));
        }

        if (flashlight != null) {
            flashlight.setPos(pos);
            flashlight.draw(g);
        }
        
        g.setTransform(old);
    }


    public Shape getBoundary() {
        AffineTransform at = new AffineTransform();
        at.translate(pos.x, pos.y);
        at.rotate(vel.heading());
        at.scale(scale, scale);
        return at.createTransformedShape(outline);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:
            case KeyEvent.VK_LEFT:  left  = true;  break;
            case KeyEvent.VK_D:
            case KeyEvent.VK_RIGHT: right = true;  break;
            case KeyEvent.VK_W:
            case KeyEvent.VK_UP:    up    = true;  break;
            case KeyEvent.VK_S:
            case KeyEvent.VK_DOWN:  down  = true;  break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A:
            case KeyEvent.VK_LEFT:  left  = false; break;
            case KeyEvent.VK_D:
            case KeyEvent.VK_RIGHT: right = false; break;
            case KeyEvent.VK_W:
            case KeyEvent.VK_UP:    up    = false; break;
            case KeyEvent.VK_S:
            case KeyEvent.VK_DOWN:  down  = false; break;
        }
    }

    @Override public void keyTyped(KeyEvent e) {}

    public PVector getPos() {
        return pos.copy();
    }
    
    public void setPos(PVector p) {
        pos.set(p);
    }

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean a) {
        alive = a;
    }
    
    public void stopAllAudio() { 
    	walkSfx.stop(); 
    }
    
    public void disposeAudio() {
    	walkSfx.dispose(); 
    }
    

}
