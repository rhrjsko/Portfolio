package com.Character.Player;
/*This is the Flashlight class. Know as the weapon for the player, you can turn on and off the flashlight using 
space bar. When turned on and shined at an enemy, it stuns them and removes them from the screen*/
import processing.core.PVector;
import java.awt.*;
import java.awt.geom.*;
import com.Util.ImageLoader;
import com.Util.SoundPlayer;

public class Flashlight {
    private final PVector pos;
    private final Color color;
    private final double scale;

    private final Polygon beamShape;   
    private final Area    outline;    
    private boolean on = false;
    private Image flashlightImage;
    private final SoundPlayer clickSfx = new SoundPlayer(); 

    private float rangeScale = 1f;  //controls range scale

    public Flashlight(int x, int y, Color c) {
        this.pos   = new PVector(x, y);
        this.color = c;
        this.scale = 0.23;

        flashlightImage = ImageLoader.loadImage("assets/flash.png");
        if (flashlightImage == null) {
            System.err.println("Failed to load assets/flashlight.png");
        }

        beamShape = new Polygon(
            new int[]{0, 120, 120},
            new int[]{0, -40,  40},
            3
        );

        outline = new Area(beamShape);
    }

    
    public void setRangeScale(float s) {
        rangeScale = Math.max(1f, Math.min(1.8f, s)); // clamp between 1x and 1.8x
    }

    public void setPos(PVector p) {
        float offsetX = 30, offsetY = 18;
        pos.set(p.x + offsetX, p.y + offsetY);
    }

    //turn on the flash light
    public void toggle() {
        on = !on;
        clickSfx.playOnce("click.mp3");
    }

    public Shape getBeamBoundary() {
        if (!on) return null;
        AffineTransform at = new AffineTransform();
        at.translate(pos.x, pos.y);
        at.scale(rangeScale, 1.0);   
        return at.createTransformedShape(outline);
    }
    
    public void draw(Graphics2D g) {
        int x = (int)pos.x, y = (int)pos.y;

        if (on) {
            AffineTransform old = g.getTransform();
            g.translate(x, y);
            g.scale(rangeScale, 1.0);                
            g.setColor(new Color(255, 255, 0, 80));
            g.fill(beamShape);
            g.setTransform(old);
        }

        if (flashlightImage != null) {
            int w = (int)(flashlightImage.getWidth(null) * scale);
            int h = (int)(flashlightImage.getHeight(null) * scale);
            AffineTransform old = g.getTransform();
            g.translate(x, y);
            g.drawImage(flashlightImage, -w/2, -h/2, w, h, null);
            g.setTransform(old);
        }
    }
}
